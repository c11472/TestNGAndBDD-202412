import org.testng.annotations.Test;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features = "src/test/java/FeatureFiles",
			glue = "StepsDefinitions",
			tags="@tag1 or @tag2")
public  class runnertest1 extends AbstractTestNGCucumberTests 
{
		
		
}



